module.exports = function(grunt) {

  grunt.initConfig({

    less: {
      production: {
        files: {
          'src/style.css': 'src/style.less'
        }
      }
    },

    postcss: {

      options: {
        processors: [
          require('autoprefixer')(),
          require('cssnano')()
        ]
      },
      dist: {
        src: 'src/style.css',
        dest: 'dest/style.css'
      }

    }
 
  });

  grunt.loadNpmTasks('grunt-postcss');
  grunt.loadNpmTasks('grunt-contrib-less');

  grunt.registerTask('css', ['less', 'postcss']);

};