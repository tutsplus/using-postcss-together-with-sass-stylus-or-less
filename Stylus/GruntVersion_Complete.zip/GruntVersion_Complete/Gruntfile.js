var poststylus = function() {
  return require('poststylus')(['autoprefixer', 'cssnano'])
};

module.exports = function(grunt) {

  grunt.initConfig({

    stylus: {
      compile: {
        options: {
          use: [poststylus]
        },
        files: {
          'dest/style.css': 'src/style.styl'
        }
      }
    }

  });

  grunt.loadNpmTasks('grunt-contrib-stylus');

};