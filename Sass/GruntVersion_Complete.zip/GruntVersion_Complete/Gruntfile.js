module.exports = function(grunt) {

  grunt.initConfig({

    sass: {
      dist: {
        files: {
          'src/style.css': 'src/style.scss'
        }
      }
    },

    postcss: {

      options: {
        processors: [
          require('autoprefixer')(),
          require('cssnano')()
        ]
      },
      dist: {
        src: 'src/style.css',
        dest: 'dest/style.css'
      }

    }

  });

  grunt.loadNpmTasks('grunt-postcss');
  grunt.loadNpmTasks('grunt-contrib-sass');

  grunt.registerTask('css', ['sass', 'postcss']);

};